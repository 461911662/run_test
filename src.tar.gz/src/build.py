#! /usr/bin/env python
import sys
import os
import tarfile

_pwd=os.path.dirname(os.getcwd())
_name="build.py"
_bin="bin"
_build="build"
_include="include"
_lib="lib"
_src="src"
outdir="out"
msg=""
prefix = "/usr/"
target_list=[]
listdic=[]
_dict = {
            "1name":[],
            "2dic":[],
            "3include":[],
            "4bin":[],
            "5lib":[],
            "6pkconfig":[],
        }

def mprint(mmsg):
    global msg
    msg = _name+": " + str(mmsg)
    print(msg)

def extra_target(arg):
    global msg
    tmpdir = _pwd + "/" + _src + "/"
    msg = "extra "+arg
    mprint(msg)

    tar = tarfile.open(tmpdir+arg)
    tmpdir = _pwd + "/" + _build + "/"

    remove = str(tmpdir+arg).rstrip(".tar.gz")
    if os.path.isdir(remove):
        mprint("remove already exists {0} directory".format(os.path.basename(remove)))
        os.system("rm -rf {0}".format(remove))

    tar.extractall(path = tmpdir)
    tar.close()

def init_workspace():
    global msg
    #1. find targets
    tmpdir = _pwd + "/" + _src + "/"
    listdir = os.listdir(tmpdir)
    mprint(listdir)
    for targets in listdir:
        if os.path.isfile(tmpdir+targets) and tarfile.is_tarfile(tmpdir+targets):
            extra_target(targets)
            target_list.append(targets)

    mprint(target_list)

    #2. read data
    tmpdir = _pwd + "/" + _build + "/"
    mprint("Entering ${0}...".format(tmpdir))
    os.chdir(tmpdir)

    for targets in target_list:
        dic = {"1name":[],"2dic":[],"3include":[],"4bin":[],"5lib":[],"6pkconfig":[],}
        mlist = dic.keys()
        mlist.sort()
        for key in mlist:
            if key == "2dic":
                dic[key].append(tmpdir+targets.rstrip(".tar.gz"))
            elif key == "1name":
                dic[key].append(targets.rstrip(".tar.gz"))
            elif key == "3include" or key == "4bin" or key == "5lib":
                if len(dic["2dic"]):
                    #mprint(dic["2dic"][0]+"/"+key[1:])
                    listfile = os.listdir(dic["2dic"][0]+"/"+key[1:])
                    for filename in listfile:
                        dic[key].append(filename)
            elif key == "6pkconfig" and len(dic["2dic"]):
                listfile = os.listdir(dic["2dic"][0]+"/")
                for filename in listfile:
                    if os.path.isfile(dic["2dic"][0]+"/"+filename) and -1 != filename.rfind(".pc"):
                        dic[key].append(filename)
        listdic.append(dic)

    #3. exec targets scripts
    for dic in listdic:
        for key in dic.keys():
            if key == "5lib":
                listfile = dic[key]
                for filename in listfile:
                    if -1 != filename.rfind(".sh") and len(dic["2dic"]):
                        mlibdir = dic["2dic"][0] + "/" + _lib
                        os.chdir(mlibdir)
                        cmd = "./{0} ".format(filename)
                        cmd = cmd + dic["2dic"][0]
                        os.system(cmd)

    mprint("Leaving {0}...".format(tmpdir))
    tmpdir = _pwd + "/" + _bin + "/"
    os.chdir(tmpdir)

def make_workspace(out):
    global outdir
    cmd = ""
    tmpdir=_pwd+"/../"+outdir
    if os.path.isdir(tmpdir):
        cmd = "rm -rf {0}/*".format(tmpdir)
        os.system(cmd)
    tmpdir=_pwd+"/../"+outdir+"/"+out
    os.mkdir(tmpdir)
    os.mkdir(tmpdir+"/"+_lib)
    os.mkdir(tmpdir+"/"+_lib+"/pkconfig")
    os.mkdir(tmpdir+"/"+_include)
    os.mkdir(tmpdir+"/"+_bin)

    for dic in listdic:
        for key in dic.keys():
            if key[1:] == "lib":
                #listfile = dic[key]
                listfile = os.listdir(dic["2dic"][0] + "/" + _lib)
                for filename in listfile:
                    if -1 == filename.rfind(".sh") and len(dic["2dic"]):
                        msrcfile = dic["2dic"][0] + "/" + _lib + "/" + filename
                        cmd = "cp -d " + msrcfile + " "
                        cmd = cmd + tmpdir + "/" + _lib
                        os.system(cmd)
            elif key[1:] == "include":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + _include + "/" + filename
                    cmd = "cp -r " + msrcfile + " "
                    cmd = cmd + tmpdir + "/" + _include
                    os.system(cmd)
            elif key[1:] == "bin":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + _bin + "/" + filename
                    cmd = "cp -d " + msrcfile + " "
                    cmd = cmd + tmpdir + "/" + _bin
                    os.system(cmd)
            elif key[1:] == "pkconfig":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + filename
                    cmd = "cp -d " + msrcfile + " "
                    cmd = cmd + tmpdir + "/" + _lib + "/" + "pkconfig/"
                    os.system(cmd)
    #mprint(tmpdir)
    return

def make_install(out):
    global prefix
    ld_cmd = out
    out = prefix + out +"_lib"
    cmd = ""
    if os.path.isdir(out):
        cmd = "rm -rf " + out
        os.system(cmd)
    os.mkdir(out)
    os.mkdir(out+"/"+_lib)
    os.mkdir(out+"/"+_lib+"/pkconfig")
    os.mkdir(out+"/"+_include)
    os.mkdir(out+"/"+_bin)

    for dic in listdic:
        for key in dic.keys():
            if key[1:] == "lib":
                #listfile = dic[key]
                listfile = os.listdir(dic["2dic"][0] + "/" + _lib)
                for filename in listfile:
                    if -1 == filename.rfind(".sh") and len(dic["2dic"]):
                        msrcfile = dic["2dic"][0] + "/" + _lib + "/" + filename
                        cmd = "cp -d " + msrcfile + " "
                        cmd = cmd + out + "/" + _lib
                        os.system(cmd)
            elif key[1:] == "include":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + _include + "/" + filename
                    cmd = "cp -r " + msrcfile + " "
                    cmd = cmd + out + "/" + _include
                    os.system(cmd)
            elif key[1:] == "bin":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + _bin + "/" + filename
                    cmd = "cp -d " + msrcfile + " "
                    cmd = cmd + out + "/" + _bin
                    os.system(cmd)
            elif key[1:] == "pkconfig":
                listfile = dic[key]
                for filename in listfile:
                    msrcfile = dic["2dic"][0] + "/" + filename
                    cmd = "cp -d " + msrcfile + " "
                    cmd = cmd + out + "/" + _lib + "/" + "pkconfig/"
                    os.system(cmd)
    
    cmd = out + "/lib"
    cmd = 'echo ' + repr(cmd) + " > /etc/ld.so.conf.d/{0}.conf".format(ld_cmd)
    os.system(cmd)
    os.system("ldconfig")
    return

def main(*arg):
    argv = list(arg[0])
    mprint("start...")
    init_workspace()
    #mprint(argv[1])
    if argv[1] != "install":
        make_workspace(os.path.basename(argv[1]))
    else:
        make_install(argv[2])

#_start
if __name__ == "__main__":
    main(sys.argv)
