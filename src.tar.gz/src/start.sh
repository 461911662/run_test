#! /bin/bash
NAME="$0"
OPTIONS="-"
outdir="laplat"
PWD=`pwd`
BUILD="source/bin"
DIR="-"

function Usage
{
	echo -e "\n${NAME}: version 0.1"
	echo "Options:"
	echo -e "\tmake: build the project."
	echo -e "\tclean: clean the project."
	echo -e "\tinstall: install exec bins,depond libs and include files etc."
	echo -e "\tuninstall: remove this project from the system.\n"
}

if [ -z $1 ];then
	Usage
	exit 1
else
	OPTIONS=$1
fi

if [ -z $2 ];then
	outdir=${PWD}/${outdir}
else
	outdir=${PWD}/${2}
fi

#__start
if [ $OPTIONS == 'make' ];then
	DIR="${PWD}/${BUILD}"	
	echo "${NAME}: make the project..."
	echo "${NAME}: Entering ${DIR}"
	cd $DIR
	./build.py $outdir
	cd ${PWD}
	echo "${NAME}: Leaving ${DIR}"
elif [ $OPTIONS == 'clean' ];then
	echo "${NAME}: clean the project"
	ls ${PWD}/out/* > .rubbish
	rm -rf ${PWD}/out/*
	rm -rf ${PWD}/source/build/*
elif [ $OPTIONS == 'install' ];then
	DIR="${PWD}/${BUILD}"	
	echo "${NAME}: install..."
	echo "${NAME}: Entering ${DIR}"
	cd $DIR
        ./build.py install `basename ${outdir}`
	cd ${PWD}
elif [ $OPTIONS == 'uninstall' ];then
	ls $PWD/out/ > .rubbish
	remove=`cat .rubbish`
	for i in $remove
	do
		echo "remove $i"
		rm -rf /usr/${i}_lib
		rm -rf /etc/ld.so.conf.d/${i}.conf
	done
	echo "${NAME}: uninstall..."
fi
